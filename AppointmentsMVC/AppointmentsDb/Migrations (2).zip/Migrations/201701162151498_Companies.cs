namespace AppointmentsDb.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Companies : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Companies",
                c => new
                    {
                        CompanyId = c.Guid(nullable: false),
                        CompanyIndex = c.Int(nullable: false, identity: true),
                        CompanyName = c.String(nullable: false, maxLength: 200),
                        AddressLine1 = c.String(nullable: false, maxLength: 200),
                        AddressLine2 = c.String(maxLength: 200),
                        TownCity = c.String(nullable: false, maxLength: 200),
                        County = c.String(maxLength: 200),
                        Postcode = c.String(nullable: false),
                        MainContactName = c.String(nullable: false, maxLength: 200),
                        MainContactEmail = c.String(nullable: false, maxLength: 200),
                        MainContactTel = c.String(nullable: false, maxLength: 12),
                        SecondaryContactName = c.String(maxLength: 200),
                        SecondaryContactEmail = c.String(maxLength: 200),
                        SecondaryContactTel = c.String(maxLength: 12),
                        IsApproved = c.Boolean(nullable: false),
                        ApprovedDate = c.DateTime(),
                        BannedDate = c.DateTime(),
                        BannedReason = c.String(),
                        Notes = c.String(maxLength: 2000),
                        ApiLiveKey = c.String(),
                        ApiTestKey = c.String(),
                        IsDeleted = c.Boolean(nullable: false),
                        Owner_ProfessionalId = c.Guid(),
                    })
                .PrimaryKey(t => t.CompanyId)
                .ForeignKey("dbo.Professionals", t => t.Owner_ProfessionalId)
                .Index(t => t.Owner_ProfessionalId);

            //TODO: CHECK THIS - IT MAY HAVE CREATED THE LINK WRONG. Search EF links to same table.
            // Scrap existing db and start again?

            //https://www.google.co.uk/search?sclient=psy-ab&client=firefox-b&biw=1370&bih=915&q=bootstrap+button+size&oq=&gs_l=&pbx=1&sns=1&pf=p&cad=cbv&bvch=u&sei=P6eDWNnCJqzagAaTj4KADg#q=EF+2+links+to+same+table
            //http://stackoverflow.com/questions/28570916/defining-multiple-foreign-key-for-the-same-table-in-entity-framework-code-first

            AddColumn("dbo.Professionals", "Company_CompanyId", c => c.Guid());
            AddColumn("dbo.Professionals", "Company_CompanyId1", c => c.Guid());
            CreateIndex("dbo.Professionals", "Company_CompanyId");
            CreateIndex("dbo.Professionals", "Company_CompanyId1");
            AddForeignKey("dbo.Professionals", "Company_CompanyId", "dbo.Companies", "CompanyId");
            AddForeignKey("dbo.Professionals", "Company_CompanyId1", "dbo.Companies", "CompanyId");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Professionals", "Company_CompanyId1", "dbo.Companies");
            DropForeignKey("dbo.Companies", "Owner_ProfessionalId", "dbo.Professionals");
            DropForeignKey("dbo.Professionals", "Company_CompanyId", "dbo.Companies");
            DropIndex("dbo.Professionals", new[] { "Company_CompanyId1" });
            DropIndex("dbo.Professionals", new[] { "Company_CompanyId" });
            DropIndex("dbo.Companies", new[] { "Owner_ProfessionalId" });
            DropColumn("dbo.Professionals", "Company_CompanyId1");
            DropColumn("dbo.Professionals", "Company_CompanyId");
            DropTable("dbo.Companies");
        }        
    }
}
