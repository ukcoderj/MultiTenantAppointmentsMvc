namespace AppointmentsDb.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class LinkingKey_Expiry : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.LinkingKeys", "ExpiryDateTime", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.LinkingKeys", "ExpiryDateTime");
        }
    }
}
