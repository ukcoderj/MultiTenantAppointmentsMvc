namespace AppointmentsDb.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RemoveNVarcharMaxFromProfessionals : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Professionals", "MiddleName", c => c.String(maxLength: 200));
            AlterColumn("dbo.Professionals", "Suffix", c => c.String(maxLength: 200));
            AlterColumn("dbo.Professionals", "Notes", c => c.String(maxLength: 1000));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Professionals", "Notes", c => c.String());
            AlterColumn("dbo.Professionals", "Suffix", c => c.String());
            AlterColumn("dbo.Professionals", "MiddleName", c => c.String());
        }
    }
}
