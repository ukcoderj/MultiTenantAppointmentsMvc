namespace AppointmentsDb.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class LinkingKey_Start : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.LinkingKeys",
                c => new
                    {
                        LinkingKeyId = c.Int(nullable: false, identity: true),
                        AvailableForEmailAddress = c.String(maxLength: 200),
                        FromTableName = c.String(maxLength: 200),
                        FromTablePK = c.String(maxLength: 200),
                        ToTableName = c.String(maxLength: 200),
                        ToTablePK = c.String(maxLength: 200),
                        SpecialKey = c.String(nullable: false, maxLength: 2000),
                        UsedDateTime = c.DateTime(nullable: false),
                        UsedByProfessionalId = c.Guid(nullable: false),
                        Owner_ProfessionalId = c.Guid(),
                    })
                .PrimaryKey(t => t.LinkingKeyId)
                .ForeignKey("dbo.Professionals", t => t.Owner_ProfessionalId)
                .Index(t => t.Owner_ProfessionalId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.LinkingKeys", "Owner_ProfessionalId", "dbo.Professionals");
            DropIndex("dbo.LinkingKeys", new[] { "Owner_ProfessionalId" });
            DropTable("dbo.LinkingKeys");
        }
    }
}
