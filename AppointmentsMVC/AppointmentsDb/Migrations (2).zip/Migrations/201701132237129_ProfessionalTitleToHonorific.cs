namespace AppointmentsDb.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ProfessionalTitleToHonorific : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Professionals", "Honorific", c => c.Int(nullable: false));
            DropColumn("dbo.Professionals", "Title");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Professionals", "Title", c => c.Int(nullable: false));
            DropColumn("dbo.Professionals", "Honorific");
        }
    }
}
