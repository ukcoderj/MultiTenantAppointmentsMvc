namespace AppointmentsDb.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ProfessionalNullableEnums : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Professionals", "Title", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Professionals", "Title", c => c.String(nullable: false, maxLength: 200));
        }
    }
}
