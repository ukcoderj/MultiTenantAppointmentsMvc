namespace AppointmentsDb.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Professionals",
                c => new
                    {
                        ProfessionalId = c.Guid(nullable: false),
                        ProfessionalIndex = c.Int(nullable: false, identity: true),
                        ProfessionalUserId = c.Guid(nullable: false),
                        Title = c.String(nullable: false, maxLength: 200),
                        Forename = c.String(nullable: false, maxLength: 200),
                        MiddleName = c.String(),
                        Surname = c.String(nullable: false, maxLength: 200),
                        Suffix = c.String(),
                        Gender = c.Int(defaultValue: 0),
                        EmailAddress = c.String(nullable: false, maxLength: 200),
                        Telephone = c.String(nullable: false, maxLength: 12),
                        TelephoneMobile = c.String(nullable: false, maxLength: 12),
                        IsAvailableForAppointments = c.Boolean(nullable: false),
                        IsApproved = c.Boolean(nullable: false),
                        ApprovalDate = c.DateTime(),
                        BannedDate = c.DateTime(),
                        BannedReason = c.String(maxLength: 500),
                        Notes = c.String(),
                        IsDeleted = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.ProfessionalId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Professionals");
        }
    }
}
