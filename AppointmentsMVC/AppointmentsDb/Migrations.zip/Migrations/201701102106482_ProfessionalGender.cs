namespace AppointmentsDb.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ProfessionalGender : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Professionals", "Gender", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Professionals", "Gender");
        }
    }
}
